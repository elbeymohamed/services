import { ClientRequest } from './clientRequest';

//import { Domain } from 'domain';
//import { ClientRequest } from 'http';

export class Personne {
    email: string;
    firstName : string;
    lastName : string;
    city: string;
    state: string;
    nCivic: number;
    street: string;
    zipCode: string;
    apartment: string;
    phone: string;
    password: string;
    typeUser: string;
    registrationDate: Date;
  //   domain: DomainsInterventions;
  //   certRequests: ClientRequest;
    // certifications: []
    
}