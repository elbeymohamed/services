import { Personne } from '../_models/Personne';
import { login } from '../_models/login';
export class Certification {
    
    id: number;
    certRequestDate : Date;
    professional: Personne;
    Admin : login ;

}