import { Personne } from '../_models/Personne';
export class ClientRequest {
    
    id: number;
    certRequestDate : Date;
    professional: Personne;
 
}
