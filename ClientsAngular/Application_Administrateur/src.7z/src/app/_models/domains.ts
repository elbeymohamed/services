import * as Collections from 'typescript-collections';
import { Intervention } from './intervention';

export class DomainsInterventions {
    domainName: string;
  //  professionnels: Collections.Set<Personne>;
   // interventions: Collections.Set<Intervention>;
   interventions: Intervention[];
}