export class Intervention {
    id: number;

    interventionName: string;

    description: string;

    domainName :string;

}