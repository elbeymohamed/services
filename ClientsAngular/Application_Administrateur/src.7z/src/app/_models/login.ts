export class login {
    
    Email : string;
    LastName : string;
    FirstName : string;
    Password : string;
    Role : string;
        
}