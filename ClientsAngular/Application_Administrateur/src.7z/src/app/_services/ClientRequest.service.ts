import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ClientRequest } from '../_models/clientRequest';
import { map } from 'rxjs/operators';
import { DomainsInterventions } from '../_models/domains';
import { login } from '../_models/login';
import { Personne } from '../_models/Personne';
import { Certification } from '../_models/certification';


@Injectable({ providedIn: 'root' })
export class ClientRequestService {
    constructor(private http: HttpClient) { }

     
    getAll() {
        console.log('${environment.apiUrl}/api/logins');

        var currentUser = JSON.parse(localStorage.getItem('currentUser'));
        var token = currentUser.value.access_token;
       var headers = new HttpHeaders().set("Authorization", "Bearer " + token);
       const listDemandes = this.http.get<ClientRequest[]>('http://localhost:7000/api/admin/CertRequests',{headers:headers});
        return listDemandes;
    }

    getAllCertifications() {
        console.log('${environment.apiUrl}/api/logins');
        var currentUser = JSON.parse(localStorage.getItem('currentUser'));
        var token = currentUser.value.access_token;
       var headers = new HttpHeaders().set("Authorization", "Bearer " + token);
       const listDemandes = this.http.get<Certification[]>('http://localhost:7000/api/admin/Certifications',{headers:headers});
        return listDemandes;
    }
// 
    getById(id: number) {
        return this.http.get(`/clientRequests/` + id);
    }

    setRequest(cRequest: ClientRequest, interventionId: number) {
        var currentUser = JSON.parse(localStorage.getItem('currentUser'));
        var token = currentUser.value.access_token;
        var headers = new HttpHeaders({'Content-Type':'application/json'})
                        .set("Authorization", "Bearer " + token);
        var c =JSON.stringify(cRequest)

        var mydata = {
            "title": cRequest.id,
            "certRequestDate": cRequest.certRequestDate,
        };
        
        this.http.post<any>('http://localhost:7000/api/client/clientRequests',mydata,{headers: headers})
         .subscribe(result => {

        });
    }

    // "deleteDemande(clientRequest)"   , interventionId: number

    deleteDemande(cRequest: ClientRequest ) {
        var currentUser = JSON.parse(localStorage.getItem('currentUser'));
        var token = currentUser.value.access_token;
        var headers = new HttpHeaders({'Content-Type':'application/json'})
                        .set("Authorization", "Bearer " + token);
        var c =JSON.stringify(cRequest)

        var mydata = {
            "title": cRequest.id,
            "certRequestDate": cRequest.certRequestDate,
        };
        
        return this.http.delete<any>('http://localhost:7000/api/admin/certRequests/'+cRequest.id,{headers: headers})
         .subscribe(result => {

        });


    }

    update(cRequest: ClientRequest) {
        return this.http.put(`/clientRequests/` + cRequest.id, cRequest);
    }


    // get list of domains and interventions
    getDomainsInterventions() {

       var currentUser = JSON.parse(localStorage.getItem('currentUser'));
       var token = currentUser.value.access_token;
       var headers = new HttpHeaders().set("Authorization", "Bearer " + token);
       const listDomains = this.http.get<DomainsInterventions[]>('http://localhost:7000/api/professionnel/CertRequests',{headers:headers});
    return listDomains;
    }

    postCertification(certification: Certification){

        var currentUser = JSON.parse(localStorage.getItem('currentUser'));
        var token = currentUser.value.access_token;
        var headers = new HttpHeaders({'Content-Type':'application/json'})
                        .set("Authorization", "Bearer " + token);
       // var c =JSON.stringify(cRequest)
        // creation pro
        //var pro = currentUser.value.personne;
        // var pro = cRequest.professional;
        // var cv = cRequest.id;

        var mydata = {
          //  "certificationDate": cRequest.certRequestDate,
          "certificationDate": "2020-03-27",
            "admin": null,
          //  "professionnel": cRequest.professional
          "professionnel":certification.professional
        };
        
        console.log("professionnel" + certification.professional.email);
        this.http.post<any>('http://localhost:7000/api/admin/Certifications',mydata,{headers: headers})
         .subscribe(result => {

        });

    }
}