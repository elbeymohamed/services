import { Component, OnInit } from '@angular/core';

import { ClientRequestService } from 'src/app/_services/ClientRequest.service';
import { ClientRequest } from 'src/app/_models/clientRequest';
import { AuthenticationService, AlertService } from 'src/app/_services';
import { Router } from '@angular/router';
import { getAttrsForDirectiveMatching } from '@angular/compiler/src/render3/view/util';
import { Certification } from 'src/app/_models/certification';

@Component({
  selector: 'app-list-demandes',
  templateUrl: './list-certifications.component.html',
  styleUrls: ['./list-certifications.component.css']
})
export class ListCertificationsComponent implements OnInit {
 //listDemandes :ClientRequest[] =[];
   listCertifications :Certification[] =[];
  constructor( private clientRequestService: ClientRequestService,
    private router:Router,
    private authenticationService:AuthenticationService,
    private alertService: AlertService, // replace with alert demande
    ) { 
      // redirect to home if already logged in
      if(!authenticationService.currentUserValue){
        this.router.navigate(['/login']);
      }
    }

  ngOnInit() {
    this.clientRequestService.getAllCertifications().subscribe((listCertifications:  Certification[])=>{
      this.listCertifications = listCertifications;
      console.log("date est  "+this.listCertifications[0].id);
   //   console.log("date est  "+listDemandes[0].id);
    });
  }

  // function to create certificat when click
  createCertif(cRequest :ClientRequest){
  let certification = new Certification();
  certification.certRequestDate = new Date();
  certification.professional = null;//cRequest.professional;
  certification.Admin=null;
  this.clientRequestService.postCertification(certification);
  }

}
