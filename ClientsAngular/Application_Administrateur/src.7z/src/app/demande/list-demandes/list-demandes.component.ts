import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';

import { ClientRequestService } from 'src/app/_services/ClientRequest.service';
import { ClientRequest } from 'src/app/_models/clientRequest';
import { AuthenticationService, AlertService } from 'src/app/_services';
import { Router } from '@angular/router';
import { getAttrsForDirectiveMatching } from '@angular/compiler/src/render3/view/util';
import { Certification } from 'src/app/_models/certification';
import { Message } from '@angular/compiler/src/i18n/i18n_ast';
//import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-list-demandes',
  templateUrl: './list-demandes.component.html',
  styleUrls: ['./list-demandes.component.css']
})
export class ListDemandesComponent implements OnInit {
 // @ViewChild('secondDialog') secondDialog: TemplateRef<any>;
 listDemandes :ClientRequest[] =[];
  dialog: any;
  constructor( private clientRequestService: ClientRequestService,
    private router:Router,
    private authenticationService:AuthenticationService,
    private alertService: AlertService, // replace with alert demande
    ) { 
      // redirect to home if already logged in
      if(!authenticationService.currentUserValue){
        this.router.navigate(['/login']);
      }
    }

  ngOnInit() {
    this.clientRequestService.getAll().subscribe((listDemandes:  ClientRequest[])=>{
      this.listDemandes = listDemandes;
      console.log("date est  "+listDemandes[0].certRequestDate);
      console.log("date est  "+listDemandes[0].id);
    });
  }

  // function to create certificat when click
  createCertif(cRequest :ClientRequest){
    console.log("ici pro" + cRequest.professional.email);
 //   if(confirm("Are you sure to delete "+cRequest.professional.email)) {
  let certification = new Certification();
  certification.certRequestDate = new Date();
  certification.professional = cRequest.professional;
  certification.Admin=null;
  this.clientRequestService.postCertification(certification);
  //  }
  }

  deleteDemande(clientRequest: ClientRequest){
    if(confirm("Are you sure to delete Request number "+clientRequest.id+"  ?")) {
    this.clientRequestService.deleteDemande(clientRequest);
    this.router.navigate(['ListDemandes']);
    alert(" Request number "+clientRequest.id+" was successfully deleted ");
  //  this.dialog.open(this.secondDialog);
   // .pipe(catchError(this.handleError('deleteHero'));
    }
  }
 // secondDialog(secondDialog: any) {
 //   throw new Error("Method not implemented.");
//  }

  clickMethod(name: string) {
    if(confirm("Are you sure to delete "+name)) {
      console.log("Implement delete functionality here");
    }
  }

}
