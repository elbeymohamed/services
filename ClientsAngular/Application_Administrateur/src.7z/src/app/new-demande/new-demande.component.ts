import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationService, AlertService } from '../_services';
import { first } from 'rxjs/operators';
import { ClientRequestService } from '../_services/ClientRequest.service';
import { ClientRequest } from '../_models/clientRequest';
import { Intervention } from '../_models/intervention';
import { DomainsInterventions } from '../_models/domains';
import * as Collections from 'typescript-collections';
import { forEach } from 'typescript-collections/dist/lib/arrays';

@Component({
  selector: 'app-new-demande',
  templateUrl: './new-demande.component.html',
  styleUrls: ['./new-demande.component.css']
})
export class NewDemandeComponent implements OnInit {
  demandeForm: FormGroup;
  loading = false;
  submitted = false;
  //domains = new Collections.Set<DomainsInterventions>();
  domains :ClientRequest[] =[];
  interventions : Intervention[]
 // private domains  =["domain 1","domain 2", "domain 3"];
  constructor(
    private formBuilder:FormBuilder,
    private router:Router,
    private authenticationService:AuthenticationService,
    private clientRequestService: ClientRequestService, // replace with demande servce
    private alertService: AlertService // replace with alert demande
  ) { 
    // redirect to home if already logged in
    if(!authenticationService.currentUserValue){
      this.router.navigate(['/login']);
    }
  }

  ngOnInit() {
    this.demandeForm = this.formBuilder.group({
     // title:['',Validators.required],
      CertRequestDate:['',Validators.required],
      Professional:['',Validators.required],
    //  domain:['',Validators.required],
    //  intervention:['',Validators.required],
    //  address:['',Validators.required],
    //  otherAddress:['',Validators.required],
    });
    //this.domains = this.clientRequestService.getDomainsInterventions();
    this.clientRequestService.getAll().subscribe((domains: ClientRequest[])=>{
      this.domains = domains;
      console.log("id du certification "+this.domains[0].id);
    });

    
  }

  //getter for easy access to form fields
  get f(){return this.demandeForm.controls}

  onSubmit(){
    this.submitted = true;

    // stop here if form is invalid
    if(this.demandeForm.invalid){
      return;
    }



    this.loading =true;
    let cRequest = new ClientRequest();
    cRequest.id=0;
    cRequest.certRequestDate= new Date();

    //
      let interventionId = 1;
    //
    return this.clientRequestService.setRequest(cRequest, interventionId);
  }

  filterInterventions(domainName : string){
    this.interventions =[];
    // this.domains.forEach(
      // d =>{
      // if(d.domainName == domainName){
      //   this.interventions = d.interventions;
      // }
    // });
  }

}
