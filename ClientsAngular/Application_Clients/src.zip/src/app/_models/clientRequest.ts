export class ClientRequest {
    id: number;
    title: string;
    description: string;
    requestDate: Date;
    status:string;
    clientId:string;
    interventionID:number;
    client:string;
    proposals:string;
    evaluations:string;
}