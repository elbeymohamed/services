export class Personne {
    email: string;
    firstName: string;
    lastName: string;
    city: string;
    state?: string;
    nCivic: number;
    street: string;
    zipCode: string;
    apartment: number
    password: string;
    typeUser: string;
    registrationDate: Date
    // domaineName: null,
    // domain: null,
    // proposals: null
}