import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ClientRequest } from '../_models/clientRequest';
import { map } from 'rxjs/operators';
import { DomainsInterventions } from '../_models/domains';


@Injectable({ providedIn: 'root' })
export class ClientRequestService {
    demande: ClientRequest;
    constructor(private http: HttpClient) { }

     
    getAll() {
        console.log('${environment.apiUrl}/api/logins');

        var currentUser = JSON.parse(localStorage.getItem('currentUser'));
        var token = currentUser.value.access_token;
       var headers = new HttpHeaders().set("Authorization", "Bearer " + token);
       const listDemandes = this.http.get<ClientRequest[]>('http://localhost:7000/api/client/clientRequests',{headers:headers});
        return listDemandes;
    }

    getdemande() {
        // var currentUser = JSON.parse(localStorage.getItem('currentUser'));
        // var token = currentUser.value.access_token;
        // var headers = new HttpHeaders().set("Authorization", "Bearer " + token);
        // const clientRequest = this.http.get<ClientRequest>('http://localhost:7000/api/client/ClientRequests/'+id,{headers:headers});
        return this.demande;
    }

    setRequest(cRequest: ClientRequest, interventionId: number) {
        var currentUser = JSON.parse(localStorage.getItem('currentUser'));
        var token = currentUser.value.access_token;
        var headers = new HttpHeaders({'Content-Type':'application/json'})
                        .set("Authorization", "Bearer " + token);
        var c =JSON.stringify(cRequest)

        var mydata = {
            "title": cRequest.title,
            "description": cRequest.description,
            "requestDate": cRequest.requestDate,
            "status":cRequest.status,
            "clientId":cRequest.clientId,
            "interventionID": cRequest.interventionID
        };
        
        return this.http.post<any>('http://localhost:7000/api/client/clientRequests',mydata,{headers: headers})
         .pipe(map( result =>{
            return result;
        }));
    }

    update(cRequest: ClientRequest) {
        return this.http.put(`/clientRequests/` + cRequest.id, cRequest);
    }


    // get list of domains and interventions
    getDomainsInterventions() {

       var currentUser = JSON.parse(localStorage.getItem('currentUser'));
       var token = currentUser.value.access_token;
       var headers = new HttpHeaders().set("Authorization", "Bearer " + token);
       const listDomains = this.http.get<DomainsInterventions[]>('http://localhost:7000/api/professionnel/domains',{headers:headers});
    return listDomains;
    }

}