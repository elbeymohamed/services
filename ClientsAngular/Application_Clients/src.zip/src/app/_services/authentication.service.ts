import { BehaviorSubject, Observable } from 'rxjs';
import { User } from '../_models/user';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class AuthenticationService {
    private currentUserSubject: BehaviorSubject<User>;
    public currentUser: Observable<User>;

    constructor (private http:HttpClient){
        this.currentUserSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('currentUser')));
        this.currentUser = this.currentUserSubject.asObservable();
    }

    // get current user value

    public get currentUserValue(): User{
        return this.currentUserSubject.value;
    }

    // login method
    login(username: string, password: string) {
       console.log('${environment.apiUrl}/api/logins');
       const headers = new HttpHeaders({'Content-Type':'application/json',
       'email':username,
       'password': password});
       return this.http.get<any>('http://localhost:7000/api/logins',{headers:headers})
              .pipe(map(user =>{
                  // store the user details and jwt in local storage
                  localStorage.setItem('currentUser',JSON.stringify(user));
                  // get personne
                //  this.http.get<any>('http://localhost:7000/api/',{headers:headers})
                  this.currentUserSubject.next(user);
                  return user;
              }));  
    }

    // LogOut method
    logout(){
        localStorage.removeItem('currentUser');
        this.currentUserSubject.next(null);
    }

}