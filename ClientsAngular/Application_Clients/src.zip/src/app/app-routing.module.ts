import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { AuthGuard } from './_Helpers/guard';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { NewDemandeComponent } from './new-demande/new-demande.component';
import { ListDemandesComponent } from './demande/list-demandes/list-demandes.component';
import { DetailDemandeComponent } from './demande/detail-demande/detail-demande.component';

const appRoutes: Routes = [
    { path: '', component: HomeComponent, canActivate: [AuthGuard] },
    { path: 'login', component: LoginComponent },
    { path: 'register', component: RegisterComponent },
    { path: 'newDemandeComponent', component: NewDemandeComponent },
    { path: 'listDemandesComponent', component: ListDemandesComponent },
    { path: 'detailsDemande', component: DetailDemandeComponent },
    // otherwise redirect to home
    { path: '**', redirectTo: '' }
];

export const routing = RouterModule.forRoot(appRoutes);
