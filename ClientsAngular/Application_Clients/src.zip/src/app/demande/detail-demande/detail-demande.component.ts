import { Component, OnInit, Input } from '@angular/core';
import { ClientRequestService } from 'src/app/_services/ClientRequest.service';
import { Router } from '@angular/router';
import { AuthenticationService, AlertService } from 'src/app/_services';
import { ClientRequest } from 'src/app/_models/clientRequest';

@Component({
  selector: 'app-detail-demande',
  templateUrl: './detail-demande.component.html',
  styleUrls: ['./detail-demande.component.css']
})
export class DetailDemandeComponent implements OnInit {
  @Input() private demande :ClientRequest;
  constructor(
    private clientRequestService: ClientRequestService,
    private router:Router,
    private authenticationService:AuthenticationService,
    private alertService: AlertService, // replace with alert demande

  ) { 
    if(!authenticationService.currentUserValue){
      this.router.navigate(['/login']);
    }
  }

  ngOnInit() {
    this.demande = this.clientRequestService.getdemande();
    // this.clientRequestService.getById(this.demande.id).subscribe((demande:  ClientRequest)=>{
    //   this.demande = demande;
    // });
  }

}
