import { Component, OnInit } from '@angular/core';

import { ClientRequestService } from 'src/app/_services/ClientRequest.service';
import { ClientRequest } from 'src/app/_models/clientRequest';
import { AuthenticationService, AlertService } from 'src/app/_services';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-demandes',
  templateUrl: './list-demandes.component.html',
  styleUrls: ['./list-demandes.component.css']
})
export class ListDemandesComponent implements OnInit {
  private listDemandes :ClientRequest[] =[];
  private selectedDemande: ClientRequest = null;
  constructor( private clientRequestService: ClientRequestService,
    private router:Router,
    private authenticationService:AuthenticationService,
    private alertService: AlertService, // replace with alert demande
    ) { 
      // redirect to home if already logged in
      if(!authenticationService.currentUserValue){
        this.router.navigate(['/login']);
      }
    }

  ngOnInit() {
    this.clientRequestService.getAll().subscribe((listDemandes:  ClientRequest[])=>{
      this.listDemandes = listDemandes;
    });
  }

  getDetails(clientRequest:ClientRequest){
     this.selectedDemande = clientRequest;
    this.clientRequestService.demande =  this.selectedDemande;
    //this.selectedDemande = clientRequest;
    this.router.navigate(['detailsDemande']);
    console.log("demande = " +this.selectedDemande.title);
  }

}
