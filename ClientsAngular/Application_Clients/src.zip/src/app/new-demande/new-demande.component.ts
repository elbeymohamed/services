import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthenticationService, AlertService } from '../_services';
import { first } from 'rxjs/operators';
import { ClientRequestService } from '../_services/ClientRequest.service';
import { ClientRequest } from '../_models/clientRequest';
import { Intervention } from '../_models/intervention';
import { DomainsInterventions } from '../_models/domains';
import * as Collections from 'typescript-collections';
import { forEach } from 'typescript-collections/dist/lib/arrays';

@Component({
  selector: 'app-new-demande',
  templateUrl: './new-demande.component.html',
  styleUrls: ['./new-demande.component.css']
})
export class NewDemandeComponent implements OnInit {
  demandeForm: FormGroup;
  loading = false;
  submitted = false;
  returnUrl:string;
  error='';
  //domains = new Collections.Set<DomainsInterventions>();
  private domains :DomainsInterventions[] =[];
  private interventions : Array<Intervention>[]= [];
  private selectedDomain:string ="";
  private interventionID: number;
 // private domains  =["domain 1","domain 2", "domain 3"];
  constructor(
    private formBuilder:FormBuilder,
    private route:ActivatedRoute,
    private router:Router,
    private authenticationService:AuthenticationService,
    private clientRequestService: ClientRequestService, // replace with demande servce
    private alertService: AlertService // replace with alert demande
  ) { 
    // redirect to home if already logged in
    if(!authenticationService.currentUserValue){
      this.router.navigate(['/login']);
    }
  }

  ngOnInit() {
    this.demandeForm = this.formBuilder.group({
      title:['',Validators.required],
      description:['',Validators.required],
      domain:['',Validators.required],
      intervention:['',Validators.required],
      address:['',Validators.required]
    });
    //this.domains = this.clientRequestService.getDomainsInterventions();
    this.clientRequestService.getDomainsInterventions().subscribe((domains: DomainsInterventions[])=>{
      this.domains = domains;
    });
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
    
  }

  //getter for easy access to form fields
  get f(){return this.demandeForm.controls}

  onSubmit(){
    this.submitted = true;
    console.log("Entered in Onsubmit()");
    // stop here if form is invalid
    if(this.demandeForm.invalid){
      return;
    }

    this.loading =true;
    let cRequest = new ClientRequest();
    var currentUser = JSON.parse(localStorage.getItem('currentUser'));
    var personne = currentUser.value.personne;
    cRequest.id=0;
    cRequest.clientId= personne.email;//this.demandeForm.get('domain').value;
    cRequest.status= 'En Attente';//this.demandeForm.get('intervention').value;
    cRequest.description= this.demandeForm.get('description').value;
    cRequest.title= this.demandeForm.get('title').value;
    cRequest.requestDate= new Date();

    //
     // let interventionId = 1;
    //
    console.log("submit request");
    this.clientRequestService.setRequest(cRequest, this.interventionID)
    .pipe(first())
    .subscribe(
            data =>{
              this.router.navigate(["/"]);
            }, 
            error =>{
              this.error = error;
              this.loading = false;
            });
  }


  filterInterventions(value: string){
 //   var domainName = event.target.value;
    this.selectedDomain = value;
    this.interventions =[];
    this.domains.forEach(d =>{
      if(d.domainName == this.selectedDomain){
        this.interventions=d.interventions;
      }
    });
  }

  getIntervention(id:number){
    this.interventionID = id;
    console.log("Intervention = "+ id)
 }

}
